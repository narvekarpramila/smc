  <div class="left-sidebar-pro">
   
     <nav id="sidebar">
        <div class="sidebar-header">
            <a href="#"><img src="{{ asset('public/admin/img/message/1.jpg') }}" alt="" />
            </a>
            <h3></h3>
        </div>
        <div class="left-custom-menu-adp-wrap">
            <ul class="nav navbar-nav left-sidebar-menu-pro">
                <li class="nav-item">                             
                    <a href="{{url('api/dealer-dashboard')}}"><i class="fa big-icon fa-home"></i> <span class="mini-dn">Home</span> </i></span></a>                                           

                </li>
                <li class="nav-item">                             
                    <a href="{{url('api/dealer/view-dealer')}}"><i class="fa big-icon fa-user"></i> <span class="mini-dn">Add Dealer</span> </i></span></a>
                </li>
                <li class="nav-item">                             
                    <a href="{{url('api/dealer/view-model')}}"><i class="fa big-icon fa-car"></i> <span class="mini-dn">Models List</span> </i></span></a>
                </li>
                <li class="nav-item">                             
                    <a href="{{url('api/dealer/view-inventory')}}"><i class="fa big-icon fa-car"></i> <span class="mini-dn">Inventory</span> </i></span></a>
                </li>

                
            </ul>
        </div>
    </nav>
</div>
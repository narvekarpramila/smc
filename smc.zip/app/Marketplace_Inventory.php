<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Marketplace_Inventory extends Model
{
    //
}

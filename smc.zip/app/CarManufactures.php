<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CarManufactures extends Model
{
    //
}

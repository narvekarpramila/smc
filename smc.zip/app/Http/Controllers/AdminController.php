<?php

namespace App\Http\Controllers;
use App\Dealer;
use Illuminate\Http\Request;
use App\User;
use App\OEM_Specs;
use Auth;
use Hash;

class AdminController extends Controller
{

   public function adminLogin(){
       return view('admin.adminLogin');
   }

   public function signIn(Request $request){
 $input = $request->all();
        $email = $input['email'];
        $password = trim($input['password']);

        if (Auth::attempt(['email' => $email, 'password' => $password, 'user_type' => 'admin'])) {       
          
                setcookie('email', $email, time() + (2592000), "/");
                setcookie('password', base64_encode($password), time() + (2592000), "/");
             
                return redirect('api/admin-dashboard'); 
                   
        } elseif(Auth::attempt(['email' => $email, 'password' => $password, 'user_type' => 'dealer'])) {       
          
                setcookie('email', $email, time() + (2592000), "/");
                setcookie('password', base64_encode($password), time() + (2592000), "/");
             
                return redirect('api/dealer-dashboard'); 
                   
        }
         else {
            return redirect('api/admin')->with('error', 'Email or password you entered is incorrect.');
        }
   }


    /**
     * randomString
     * @param $length length
     * @return randomString
     */
     function generateRandomString($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }



     public function adminRegister(){
      return view('register');
     }

     /*     * Function: saveUser

     * Register new resource for user table and assign default free package in user_subscription table.
     *
     */

     public function adminSignUp(Request $request){

        $user = new User;
        $token = $this->generateRandomString('20');
        $user->name = $request->name;
        $user->phone_no = $request->phone_no;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $user->remember_token = $token;
        $user->user_type='customer';
        $user->save();
        return redirect('/');

    }

     /** Function: logout
     * Logout the user.**/
     public function logout(Request $request) {
        Auth::guard()->logout();
        $request->session()->invalidate();
        return redirect('/');
    }

 public function index(Request $request)
  {
     $search = $request->search;
     if ($search==NULL) {
      $oem_specs =OEM_Specs::all();
    }else{
  $oem_specs = OEM_Specs::where('model_name', 'LIKE','%'.$search.'%')->get();
    }
    return view('index')->with('oem_specs',$oem_specs);
  }

   public function dashboard(Request $request){
     $search = $request->search;
     if ($search==NULL) {
      $oem_specs =OEM_Specs::all();
    }else{
  $oem_specs = OEM_Specs::where('model_name', 'LIKE','%'.$search.'%')->get();
    }
      return view('admin.adminDashboard')->with('oem_specs',$oem_specs);
   }

	public function addDealer(){
       return view('admin.addDealer');
   }


 public function saveDealer(Request $request){
    $dealer = Dealer::where('id', $request->id)->first();
    if (!isset($dealer) && $dealer == '') {
        $dealer= new Dealer;
    }
    $dealer->name=$request->name;
    $dealer->address=$request->address;
    $dealer->phone_no=$request->phone_no;
    $dealer->save();
    return redirect('api/admin/view-dealer');
}

public function editDealer($id){
   $id = base64_decode($id);
    $dealer= Dealer::find($id);
   return view('admin.addDealer')->with('dealer',$dealer);
}



public function viewDealer(){
 $dealer=Dealer::all();
 return view('admin.ViewDealer')->with('dealer',$dealer);
}


public function getModelDetails(){
  $models= OEM_Specs::select('model_name')->get();
  return view('admin.viewModel')->with('models',$models);
}

public function getSearch(Request $request){
  $search = $request->search;

  $details = OEM_Specs::where('model_name', 'LIKE','%'.$search.'%')->get();
  return $details;
}
}


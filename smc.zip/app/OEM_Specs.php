<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OEM_Specs extends Model
{
    //
}

<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AdminController;


Route::get('login/{email_address?}',['uses' => 'HomeController@login', 'as' => 'log-in']);
Route::post('login', ['uses' => 'HomeController@sign_in', 'as' => 'login']);

Route::get('/logout',['uses' => 'HomeController@logout', 'as' => 'signout']);
Route::get('signup',['uses' => 'HomeController@signup', 'as' => 'signup']);
Route::post('signup', ['uses' => 'HomeController@register']);

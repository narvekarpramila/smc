<!DOCTYPE html>
<html lang="en">
<head>
  <title>SMC</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <style>
  .fakeimg {
    height: 200px;
    background: #aaa;
  }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <a class="navbar-brand" href="#">Navbar</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="#">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">About</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Contact</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('api/admin')); ?>">Login</a>
      </li>    
    </ul>
  </div>  
</nav>

<div class="container" style="margin-top:30px">
  
  <div class="row">
    <div class="col-md-12" style="margin-top: 30px">
      <form class="" method="get" action="<?php echo e(url('api/')); ?>">
                                     <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                   <div class="input-group mb-3">
  <input type="text" class="form-control" placeholder="Search" name="search">
  <div class="input-group-append">
    <button class="btn btn-success" type="submit">Go</button>
  </div>
</div>
                                </div>
                                </form>
                              </div>
    <?php if(isset($oem_specs) && count($oem_specs) > 0): ?>
<?php $__currentLoopData = $oem_specs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oem_specs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   
        <div class="col-md-12" style="margin-top: 30px">
              <div class="sparkline8-list shadow-reset">
                    <div class="sparkline8-hd ht">
                        <div class="main-sparkline8-hd">
            <h1> <?php echo e($oem_specs->model_name); ?></h1> <hr>
            <div class="col-md-4">
            <h5>Year : <?php echo e($oem_specs->year_of_model); ?></h5>
            </div>
              <div class="col-md-4">
            <h5>Price : <?php echo e($oem_specs->price); ?></h5>
            </div>
              <div class="col-md-4">
            <h5>Color : <?php echo e($oem_specs->color); ?></h5>
            </div>
             <div class="col-md-4">
            <h5>Mileage : <?php echo e($oem_specs->mileage); ?></h5>
            </div>
             <div class="col-md-4">
            <h5>Power : <?php echo e($oem_specs->power); ?></h5>
            </div>
             <div class="col-md-4">
            <h5>Max Speed : <?php echo e($oem_specs->max_speed); ?></h5>
            </div>
        </div>
    </div>
</div>
        </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<p> Result not found</p>
<?php endif; ?>
    </div>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\SMC\resources\views/index.blade.php ENDPATH**/ ?>
<div class="footer">
    <div class="container-fluid p box-shadow">
        <div class="row ft-copyright pt-2 pb-2 mr-0 ml-0 ">    
            <div class="text-center col-md-12">Copyright &COPY; <?php echo e(date('Y')); ?>, All right reserved to <a href=<?php echo e(url('home')); ?>>Excel V Corporation.</a></div>   
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\SMC\resources\views/layouts/admin/webapp_footer.blade.php ENDPATH**/ ?>